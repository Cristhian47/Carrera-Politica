var classgame__core_1_1_stats_data =
[
    [ "variableName", "classgame__core_1_1_stats_data.html#ad9ea3da10e9324dc58798e45f1d069ff", null ]
];