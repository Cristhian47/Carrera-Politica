var classgame__core_1_1_text_view =
[
    [ "TextView", "classgame__core_1_1_text_view.html#a9d8eae166caec14d39baea0d458b85a5", null ],
    [ "active", "classgame__core_1_1_text_view.html#a048fde5ba90ecdc66fa274e63d01c1d1", null ],
    [ "gameObject", "classgame__core_1_1_text_view.html#a4700d66982ec1741468ebe4321a3c91b", null ],
    [ "position", "classgame__core_1_1_text_view.html#a900e7e4ce3c77bbef8004338512862db", null ],
    [ "rectTransform", "classgame__core_1_1_text_view.html#a484a7694356de41455479dad1691b3ea", null ],
    [ "text", "classgame__core_1_1_text_view.html#ae98fd992c18876a93147a79cc2ab0332", null ],
    [ "transform", "classgame__core_1_1_text_view.html#a733e3d22a6f55d70d90a4566bccdaf0f", null ]
];