var classgame__core_1_1_social_canvas_button =
[
    [ "action", "classgame__core_1_1_social_canvas_button.html#ad2706e586904274c5a75fb70db189dde", null ],
    [ "Start", "classgame__core_1_1_social_canvas_button.html#a4a40ba59c03d84a51874fd6cf3581223", null ],
    [ "caption", "classgame__core_1_1_social_canvas_button.html#ae07e48acdf145767abc74e7ae7a5dd71", null ],
    [ "description", "classgame__core_1_1_social_canvas_button.html#a9e885311397d77c93529e1e338662d01", null ],
    [ "FBAppID", "classgame__core_1_1_social_canvas_button.html#a4d7495d840acae082dad93be9efccbee", null ],
    [ "FBRedirectUri", "classgame__core_1_1_social_canvas_button.html#a067d84fd323ebb858453a8ebfb0b030b", null ],
    [ "hashtags", "classgame__core_1_1_social_canvas_button.html#ac19ff1f21e6cd67728c069b5f56df7cc", null ],
    [ "title", "classgame__core_1_1_social_canvas_button.html#a54d903a78ca4d19fa23ae7a432824896", null ],
    [ "url", "classgame__core_1_1_social_canvas_button.html#aec681d8d633fb6b6a77ef72f03c1a9d1", null ],
    [ "variableName", "classgame__core_1_1_social_canvas_button.html#a42473e4114cfdeb1857077df12d27e4f", null ]
];