var classgame__core_1_1_link_canvas_button =
[
    [ "action", "classgame__core_1_1_link_canvas_button.html#ad7ec0d0beeb24d404a120162ac08a8ed", null ],
    [ "link", "classgame__core_1_1_link_canvas_button.html#a98e1e273a351bc767bc2bbaac6e1314a", null ]
];