var classgame__core_1_1_channel =
[
    [ "channelID", "classgame__core_1_1_channel.html#a45f20199a654c8fe6028d06e4da8cce4", null ],
    [ "audioSource", "classgame__core_1_1_channel.html#a92d1a1f8ea63e38046299ba387a61cfd", null ]
];