var classgame__core_1_1_splash_behaviour =
[
    [ "activeAds", "classgame__core_1_1_splash_behaviour.html#aa986ad4e1f0baadad6ee62a8770e444e", null ],
    [ "sceneName", "classgame__core_1_1_splash_behaviour.html#a74a32bf94f3a43b626f583c71b12a285", null ],
    [ "timeOut", "classgame__core_1_1_splash_behaviour.html#a50c13cf93fff8d61910d60210183d3b6", null ]
];