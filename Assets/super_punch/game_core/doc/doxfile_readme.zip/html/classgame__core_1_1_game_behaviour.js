var classgame__core_1_1_game_behaviour =
[
    [ "collectedCoins", "classgame__core_1_1_game_behaviour.html#aae6ec1d1ec0bf395c9ae9fab638bc74c", null ],
    [ "saveThePrince", "classgame__core_1_1_game_behaviour.html#a966bfc5e7f39b20b6964dddbd05e2739", null ],
    [ "timeOut", "classgame__core_1_1_game_behaviour.html#a964e46de575cc99addc6acee9509f10c", null ]
];