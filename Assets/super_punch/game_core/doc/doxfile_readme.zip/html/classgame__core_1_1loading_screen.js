var classgame__core_1_1loading_screen =
[
    [ "backgroundColor", "classgame__core_1_1loading_screen.html#ade17ea733a909bf9b8110004d3f9d724", null ],
    [ "message", "classgame__core_1_1loading_screen.html#ac1b846505a24556fdfc5ebbb15a0b9ad", null ],
    [ "style", "classgame__core_1_1loading_screen.html#aeea107c29a0226e0d7b7783f3a81648f", null ],
    [ "textColor", "classgame__core_1_1loading_screen.html#a53398f123419ceb0585f15cab921524a", null ]
];