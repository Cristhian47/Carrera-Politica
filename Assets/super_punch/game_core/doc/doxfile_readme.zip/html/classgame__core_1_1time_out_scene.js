var classgame__core_1_1time_out_scene =
[
    [ "sceneName", "classgame__core_1_1time_out_scene.html#ab685869484eaa7956476b1ab878261f2", null ],
    [ "timeOut", "classgame__core_1_1time_out_scene.html#a26eaed57fce0a0d5e0ec2b3dd423e1cc", null ]
];