var searchData=
[
  ['update',['Update',['../classgame__core_1_1_button_behaviour.html#a5c6ce1529b8ed2a277090967077df4f5',1,'game_core.ButtonBehaviour.Update()'],['../classgame__core_1_1_touch_behaviour.html#a04211c87c838cab35cbcf92d2893a509',1,'game_core.TouchBehaviour.Update()']]]
];
