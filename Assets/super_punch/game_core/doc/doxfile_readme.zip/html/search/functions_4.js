var searchData=
[
  ['getobject',['getObject',['../classgame__core_1_1_object_pool.html#a3113eac0ff233f5fd6b0d8217435090d',1,'game_core::ObjectPool']]]
];
