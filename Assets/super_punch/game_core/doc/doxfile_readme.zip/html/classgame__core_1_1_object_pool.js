var classgame__core_1_1_object_pool =
[
    [ "activateObject", "classgame__core_1_1_object_pool.html#aa4ddce332f15439e2427749bc8018091", null ],
    [ "getObject", "classgame__core_1_1_object_pool.html#a3113eac0ff233f5fd6b0d8217435090d", null ],
    [ "numberOfObjects", "classgame__core_1_1_object_pool.html#aad627c91eb2040551e1475f40d650fff", null ],
    [ "objectPool", "classgame__core_1_1_object_pool.html#adc288c88a6d16c02ce15ec5696ef861e", null ],
    [ "objectQueue", "classgame__core_1_1_object_pool.html#a110b2993db7a65fd5ce5e577fbe40dae", null ],
    [ "prefab", "classgame__core_1_1_object_pool.html#ab5095ab3e30d867c38639c74d3d6b31a", null ]
];