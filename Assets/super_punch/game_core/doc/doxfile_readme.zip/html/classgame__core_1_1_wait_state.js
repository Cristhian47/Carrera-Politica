var classgame__core_1_1_wait_state =
[
    [ "WaitState", "classgame__core_1_1_wait_state.html#a61cea4382cb5cace21ba470ac54d44ff", null ],
    [ "Act", "classgame__core_1_1_wait_state.html#ab1d0dd75b49646f9cb91d27938189f8b", null ],
    [ "DoBeforeEntering", "classgame__core_1_1_wait_state.html#a35c83058087bc4b7798ff23909be30cd", null ],
    [ "DoBeforeLeaving", "classgame__core_1_1_wait_state.html#a10d8a07e221cfa0e4585f9510eb832ee", null ],
    [ "Reason", "classgame__core_1_1_wait_state.html#ac716bff77dca0fef90282b2cb07e72a1", null ]
];