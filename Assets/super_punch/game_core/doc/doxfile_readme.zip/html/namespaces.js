var namespaces =
[
    [ "achievement_system", "namespaceachievement__system.html", null ],
    [ "game_core", "namespacegame__core.html", null ]
];