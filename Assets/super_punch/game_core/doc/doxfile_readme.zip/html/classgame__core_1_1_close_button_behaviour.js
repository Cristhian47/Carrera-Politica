var classgame__core_1_1_close_button_behaviour =
[
    [ "action", "classgame__core_1_1_close_button_behaviour.html#a5a18866ffa5afde2029b1dbae2a90b94", null ],
    [ "soundEffect", "classgame__core_1_1_close_button_behaviour.html#a1fb5f8af20c6793386fa13a1315ee907", null ]
];