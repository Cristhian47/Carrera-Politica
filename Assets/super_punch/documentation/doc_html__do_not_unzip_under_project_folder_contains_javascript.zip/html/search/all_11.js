var searchData=
[
  ['updatefighterhealth',['updateFighterHealth',['../class_fighter_controller.html#aa773bcaae89b5bd978b2fdbd1851ed00',1,'FighterController']]],
  ['updatefighterpower',['updateFighterPower',['../class_fighter_controller.html#aeaddbfb9d12168e73b670fd4304d19e3',1,'FighterController']]]
];
