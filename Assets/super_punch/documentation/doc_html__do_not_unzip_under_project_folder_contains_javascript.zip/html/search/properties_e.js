var searchData=
[
  ['soundeffects',['soundEffects',['../class_game_behaviour.html#a5caded7b59ae08a04ac271aa6f0fffed',1,'GameBehaviour']]],
  ['succeedhits',['SucceedHits',['../class_fighter_controller.html#af71dee5cc1eb4fc567269f91df774518',1,'FighterController']]],
  ['superpunchhits',['SuperPunchHits',['../class_fighter_controller.html#ad8590fbb04e0df3e69711078d0d9bf5f',1,'FighterController']]]
];
