var searchData=
[
  ['remove',['remove',['../class_finger_event.html#a2fee0821cb75c4d6d2449cb5e4651650',1,'FingerEvent']]]
];
