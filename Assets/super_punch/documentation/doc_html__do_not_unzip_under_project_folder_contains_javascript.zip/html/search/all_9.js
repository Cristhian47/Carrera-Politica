var searchData=
[
  ['knockoutinfo',['KnockOutInfo',['../class_fighter_controller.html#a22ab0325a70c3b4b471f9a909de7b1ec',1,'FighterController']]],
  ['knockouts',['KnockOuts',['../class_fighter_controller.html#a0e20545cf98cecf4eb191b69b46c08b2',1,'FighterController']]]
];
