var class_fighter_injury_behaviour =
[
    [ "OnEnable", "class_fighter_injury_behaviour.html#a3f103a298128d2875cff5df3fce3fd48", null ],
    [ "OnTouchBegan", "class_fighter_injury_behaviour.html#aa60f1783e7655fbaa4f95112dc858c05", null ],
    [ "onCuredSFX", "class_fighter_injury_behaviour.html#a7d116f1342b23b020dff5555ce00bd84", null ],
    [ "onTouchSFX", "class_fighter_injury_behaviour.html#ad6d64c903ef6036ec77bba7e94fb1750", null ],
    [ "HitsLimit", "class_fighter_injury_behaviour.html#a88c7418ea1d1f48c718e4ecdf8119949", null ]
];