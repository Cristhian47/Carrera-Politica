var hierarchy =
[
    [ "BloodMeterModel", "interface_blood_meter_model.html", [
      [ "BloodMeter", "class_blood_meter.html", null ]
    ] ],
    [ "ButtonBehaviour", null, [
      [ "SelectBehaviour", "class_select_behaviour.html", null ]
    ] ],
    [ "FighterModel", "interface_fighter_model.html", [
      [ "FighterController", "class_fighter_controller.html", null ]
    ] ],
    [ "FingerEvent", "class_finger_event.html", null ],
    [ "HitData", "class_hit_data.html", null ],
    [ "MonoBehaviour", null, [
      [ "BloodBehaviour", "class_blood_behaviour.html", null ],
      [ "BloodMeter", "class_blood_meter.html", null ],
      [ "FighterController", "class_fighter_controller.html", null ],
      [ "FighterController", "class_fighter_controller.html", null ],
      [ "FighterInjuredBehaviour", "class_fighter_injured_behaviour.html", null ],
      [ "FPSCounter", "class_f_p_s_counter.html", null ],
      [ "GameBehaviour", "class_game_behaviour.html", null ],
      [ "headController", "classhead_controller.html", null ],
      [ "MultiTouchController", "class_multi_touch_controller.html", null ],
      [ "ObjectBehaviour", "class_object_behaviour.html", null ],
      [ "ObjectPool", "class_object_pool.html", null ],
      [ "PlayHurtEffects", "class_play_hurt_effects.html", null ],
      [ "PunchController", "class_punch_controller.html", null ],
      [ "RoundGirlBehaviour", "class_round_girl_behaviour.html", null ],
      [ "SpawnerBehaviour", "class_spawner_behaviour.html", null ],
      [ "testPunchBag", "classtest_punch_bag.html", null ]
    ] ],
    [ "State", null, [
      [ "GameBehaviour.endRound", "class_game_behaviour_1_1end_round.html", null ],
      [ "GameBehaviour.fight", "class_game_behaviour_1_1fight.html", null ],
      [ "GameBehaviour.GameOver", "class_game_behaviour_1_1_game_over.html", null ],
      [ "GameBehaviour.InitCombat", "class_game_behaviour_1_1_init_combat.html", null ],
      [ "GameBehaviour.limitRoundReached", "class_game_behaviour_1_1limit_round_reached.html", null ],
      [ "GameBehaviour.PlayerLoses", "class_game_behaviour_1_1_player_loses.html", null ],
      [ "GameBehaviour.PlayerWins", "class_game_behaviour_1_1_player_wins.html", null ],
      [ "GameBehaviour.startRound", "class_game_behaviour_1_1start_round.html", null ]
    ] ],
    [ "TouchBehaviour", null, [
      [ "FighterInjuryBehaviour", "class_fighter_injury_behaviour.html", null ],
      [ "GamePadController", "class_game_pad_controller.html", null ]
    ] ]
];