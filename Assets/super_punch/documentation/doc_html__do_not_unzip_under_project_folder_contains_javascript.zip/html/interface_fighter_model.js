var interface_fighter_model =
[
    [ "GoToInitialPosition", "interface_fighter_model.html#a594c6191a2915e34db74a97a539ffa35", null ],
    [ "SetTransition", "interface_fighter_model.html#a9149cc9753511c17ba702cbd0a20a67c", null ],
    [ "currentState", "interface_fighter_model.html#aab029f8a6ca7eb4b29c900637cc5aa51", null ],
    [ "Enable", "interface_fighter_model.html#ac963f190caff503e0c019ff99ac634d9", null ],
    [ "Health", "interface_fighter_model.html#ae17e43379af5834ac0d9b0fb37b153ed", null ],
    [ "IsActive", "interface_fighter_model.html#a1f7c8a3adb70ff8ad3e2045e20b87530", null ],
    [ "isDead", "interface_fighter_model.html#a56e04a3ebcb4f9beb60cd2ec4b8b3623", null ],
    [ "IsHuman", "interface_fighter_model.html#add4267ceaeba7b8107f0ea0d785c1561", null ],
    [ "KnockOuts", "interface_fighter_model.html#a10cd95d2a1318c0e552976fa9ed0646a", null ],
    [ "OnHitSucceed", "interface_fighter_model.html#ad67ca0a2e5ee5bb066443d3644bf4972", null ],
    [ "Position", "interface_fighter_model.html#a3d05c0a2d3d3310e0640584db275b5a9", null ],
    [ "Tag", "interface_fighter_model.html#a78bfe1e2188da1173a1045c3851dc03e", null ],
    [ "TotalSucceedHits", "interface_fighter_model.html#a29cfe618a456a8bab80203f96466608e", null ]
];