var class_game_behaviour_1_1_game_over =
[
    [ "GameOver", "class_game_behaviour_1_1_game_over.html#abad6bea9a92af5090f9d91e9e7d94bf2", null ],
    [ "Act", "class_game_behaviour_1_1_game_over.html#afd50e5c4d78d11be964895c76884e58b", null ],
    [ "DoBeforeEntering", "class_game_behaviour_1_1_game_over.html#a981104a79b1b2fee809f3163543f7e02", null ],
    [ "DoBeforeLeaving", "class_game_behaviour_1_1_game_over.html#a0cf120a2d18eb2b5aa03a2bf6203ccb5", null ],
    [ "Reason", "class_game_behaviour_1_1_game_over.html#aafb6ece9e949409ac0a40b9bc0577b9f", null ]
];