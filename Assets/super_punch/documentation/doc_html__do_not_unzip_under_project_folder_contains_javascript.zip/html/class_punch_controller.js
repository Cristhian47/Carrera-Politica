var class_punch_controller =
[
    [ "defense", "class_punch_controller.html#aeb1708cc50e0e82025d4458eb028ce2b", null ],
    [ "effectivePower", "class_punch_controller.html#a1616853fb877629b2370429b2c93b1de", null ],
    [ "Hits", "class_punch_controller.html#ad56a42dc1fa2658cae947d56711cbe2d", null ]
];