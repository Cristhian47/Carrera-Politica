var class_blood_meter =
[
    [ "bloodDownFactor", "class_blood_meter.html#ab447f3a64f1f111444942ea68435d431", null ],
    [ "bloodFactor", "class_blood_meter.html#ae6366f1fec8138f93a718b7b22c5cdf1", null ],
    [ "maxBlood", "class_blood_meter.html#aea2fa7f79da1e4e0384186ef55649f1a", null ],
    [ "totalBlood", "class_blood_meter.html#a8bf5d0c8f3c6ea958bcffac06f3344bd", null ],
    [ "MaxBlood", "class_blood_meter.html#a71657854231de12ffa35f4a5e669c2bb", null ],
    [ "Measure", "class_blood_meter.html#abc162df1c3761cf386747784e513015a", null ],
    [ "RelativeMeasure", "class_blood_meter.html#a793de38b064e889b13f630678a85a14a", null ]
];