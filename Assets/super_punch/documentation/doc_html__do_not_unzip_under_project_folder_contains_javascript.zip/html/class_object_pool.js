var class_object_pool =
[
    [ "activateObject", "class_object_pool.html#a4d60684d2689c005a62481082b7c8a94", null ],
    [ "numberOfObjects", "class_object_pool.html#a63585d2592d849b3e2960b179403f1f0", null ],
    [ "objectPool", "class_object_pool.html#ad3ed2117b619acfe6b7beca1a0f02103", null ],
    [ "prefab", "class_object_pool.html#a42516eea413de7b8afb7da411618a9da", null ]
];